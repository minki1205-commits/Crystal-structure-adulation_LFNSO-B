# LFNSO21-B structure discovery

마스터 프롬프트: [docs/MASTER_PROMPT.md](docs/MASTER_PROMPT.md).

현재 첫 구현은 **연구 파이프라인 기반 및 negative controls**입니다. 구조 해석이나 최종 탐색 완료를 의미하지 않습니다.

## 실행

Python 3.12에서 저장소 루트를 작업 디렉터리로 사용합니다.

```bash
python3 -m venv /workspace/lfnso-venv
/workspace/lfnso-venv/bin/pip install -r requirements.lock.txt
/workspace/lfnso-venv/bin/python -m pytest -q
PYTHONPATH=src /workspace/lfnso-venv/bin/python -m lfnso.pipeline configs/audit.json
```

`configs/audit.json`의 모든 경로는 설정 파일 기준입니다. 출력 경로는 새 디렉터리여야 합니다. 재실행 시 새 cycle 이름을 지정합니다. 원본 및 기존 결과 덮어쓰기를 허용하지 않습니다.

실제 parent CIF가 도착하면 `parent_cif`에 경로를 지정하세요. XRD 예측에는 명시적인 `wavelength_A`가 필요합니다. 테스트의 NaCl 좌표와 파장은 수학적 검증 fixture이며 LFNSO 실험값이 아닙니다.

## 구현 및 한계

- 파일 해시, 출처 경로 및 미제공 metadata 목록
- row-vector convention, Å⁻¹ (2π 제외)의 reciprocal transformation
- exact-repeat 1b/3b/4b CIF 및 조성 기록
- pymatgen 이상적 powder XRD 및 geometric reflection table
- 단순 반복 소멸, 지수/zone 변환, CIF roundtrip, XRD 불변성 테스트
- HTML/JSON 상태 보고서. 실험 제약 미제공은 gate 통과로 처리하지 않음

아직 구현되지 않은 기능: 실험 peak extraction/scoring, parent refinement, O/D/S 변조 생성, slab/O 연결성 검증, disorder ensemble, Pareto ranking, checkpoint/cache, FFT/IFFT, STEM multislice. 조성/occupancy와 최소 site 간 거리는 제한적 검사이며 완전한 화학 검증이 아닙니다. ED 테이블은 기하학적 위치만 제공하며 전자 산란 강도를 계산하지 않습니다.

## 필요한 입력

현재 클라우드에는 이전 Windows 프로젝트 및 Work 자료가 없습니다.

1. 기존 parent CIF와 4b/6b/AABB 모델, 생성 코드 및 report
2. XRD raw data, 파장, calibration 및 측정 조건
3. ED/FFT/원본 STEM(DM3/DM4/TIFF), zone axis, pixel calibration 및 원본 간 관계

원본은 별도로 보관하고 manifest에서 경로/해시를 추적합니다. 민감하거나 큰 실험 파일을 무조건 Git에 추가하지 마세요.

## 작업 연속성

직장과 집에서 동일 GitHub 저장소의 커밋을 기준으로 개발을 이어갑니다. 현재 생성한 코드는 클라우드 작업 폴더에 있으며 아직 커밋/푸시하지 않았습니다. 환경 게시와 GitHub 코드 동기화는 별개의 작업입니다. 각 cloud task는 격리되어 있으므로 기존 체크아웃을 사용하고, 명시적인 요청 없이는 Git worktree를 만들지 않습니다.

## 첨부 자료 분석 업데이트

[1차 실제 데이터 분석 기록](docs/FIRST_DATA_SURVEY.md)에 calibration, 피크 추출 결과와 입력 요구사항을 정리했습니다. NCEMpy DM3/DM4 reader, 수치 이상 검출, 배경 제거 후 피크 후보 검출, 반대편 반사쌍 중심 추정, Hann FFT 및 저장 FFT 중복 검증을 추가했습니다. `configs/uploaded_survey.json`으로 실행합니다. 앞의 초기 구현 목록 이후 확장된 기능이며 hkl 지수화와 구조 scoring은 여전히 미구현입니다.

XRD 그림과 추가 TIFF를 사용한 [위치 가설 비교](docs/POSITION_SCREENING.md)를 추가했습니다. `configs/position_screening.json`으로 manual XRD 위치·고정 격자 satellite 가설·경험적 ED q·TIFF scale bar 좌표를 재현할 수 있습니다. 자동 XRD digitization이나 원자 구조 ranking 결과가 아닙니다. XRD metric–q 민감도, 절대 ED calibration 및 monoclinic axis convention 문제를 결과와 함께 보존했습니다.

수치 XRD 프로파일의 최신 결과는 [RAW_XRD_ANALYSIS.md](docs/RAW_XRD_ANALYSIS.md)에 있습니다. 세 시료 3501점씩을 읽고 22개 feature를 피팅했습니다. `configs/raw_xrd.json`을 사용하며, Cu Kα 파장은 사용자 제안에 따른 잠정 가정입니다. 이 분석의 수치 피크가 앞선 XRD 그림 판독값을 대체합니다. 정확한 4b 확정 대신 조건부 δ≈0.278, q≈0.311 nm⁻¹ 및 남은 indexing/calibration/overlap 문제를 기록했습니다.

조성 및 Ni의 Fe-site 치환 가정을 반영한 [32개 가설 구조 생성·비교](docs/COMPOSITION_MODEL_SEARCH.md)를 수행했습니다. 31개는 정확한 소수 조성을 보존하고, 정수 배열 1개는 2/3:1/3 근사입니다. 위치가 가까운 일부 모델도 실제 B 강도 분포를 재현하지 못했으므로 최종 구조로 채택하지 않았습니다. 생성 CIF와 계산 결과는 composition_models_02 / composition_models_03에 있습니다.

추가로 [조성 보존 자리 배열 탐색](docs/OCCUPATIONAL_SEARCH.md)을 수행했습니다. 4b/7b/11b와 두 격자에서 20개 탐색 종점 CIF를 생성했고, 총 88,000 proposal 중 60,230회를 회절 평가했습니다. 조건부 B 격자·11b 후보가 지정 superstructure 구간에서 가장 높은 점수를 얻었지만 불필요한 반사와 강도 불일치가 남습니다. 최신 진단은 `03_structure_model_search/occupational_assessment_03/report.html`, 재현 설정은 `configs/occupational_search*.json`과 `configs/occupational_assessment.json`에 있습니다. 최종 구조 확정이나 STEM 검증 통과를 의미하지 않습니다.
